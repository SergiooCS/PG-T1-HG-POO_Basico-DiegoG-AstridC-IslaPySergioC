package constructor;

public class Main {
    //Especificamos contenido de los atributos
	public static void main(String[] args) {
		Usuario u1 = new Usuario("Diego",19);
		//Creamos método para mostrar variables
		u1.datosConstructor();

	}

}