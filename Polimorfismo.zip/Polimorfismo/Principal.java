
public class Principal {

	public static void main(String[] args) {
		Futbol futbolista=new Futbol("Pelota",2);
		Baloncesto baloncesto1=new Baloncesto("Pelota",2);
		
		futbolista.Jugar();
		baloncesto1.Jugar();

	}

}
