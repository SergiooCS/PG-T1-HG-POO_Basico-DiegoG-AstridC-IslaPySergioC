
public class Baloncesto extends Deporte {

	//CONSTRUCTOR
	public Baloncesto(String balon, int piernas) {
		super(balon, piernas);
	}
	
	//M�TODOS
	public void Jugar(){
		System.out.println("Boto el bal�n");
	}
}
